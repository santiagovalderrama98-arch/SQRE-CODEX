"""SQRE package."""
